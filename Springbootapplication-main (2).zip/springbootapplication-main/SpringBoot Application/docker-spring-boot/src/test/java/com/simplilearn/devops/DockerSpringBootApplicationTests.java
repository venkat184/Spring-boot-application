package com.simplilearn.devops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
